// zlxFTH OvO
#include <bits/stdc++.h>
using namespace std;

using LL = long long;

struct DSU {
  vector<int> f, s;
  DSU(int n) : f(n), s(n, 1) {
    iota(f.begin(), f.end(), 0);
  }
  int find(int u) {
    while (u != f[u]) u = f[u] = f[f[u]];
    return u;
  }
  bool merge(int u, int v) {
    u = find(u);
    v = find(v);
    if (u == v) return false;
    s[v] += s[u];
    f[u] = v;
    return true;
  }
  int size(int u) {
    return s[find(u)];
  }
  bool same(int u, int v) {
    return find(u) == find(v);
  }
  vector<vector<int>> groups() {
    vector<vector<int>> res(f.size());
    for (int u = 0; u < f.size(); ++u) {
      res[find(u)].emplace_back(u);
    }
    res.erase(remove_if(res.begin(), res.end(), [&](auto g) {
      return g.empty();
    }), res.end());
    return res;
  }
};

struct Tree {
  int n, cur = 0, o1 = 0;
  vector<int> siz, par, dep, in, out, top, seq;
  vector<vector<int>> G;
  Tree(int n = 0) : n(n), G(n), siz(n), par(n), dep(n), in(n), out(n), top(n), seq(n) {}
  void addEdge(int u, int v) {
    G[u].emplace_back(v);
    G[v].emplace_back(u);
  }
  void init(int rt = 0) {
    par[rt] = -1;
    dfs1(rt);
    dfs2(rt, rt);
  }
  void dfs1(int u) {
    if (par[u] != -1) {
      G[u].erase(find(G[u].begin(), G[u].end(), par[u]));
    }
    siz[u] = 1;
    for (auto &v : G[u]) {
      par[v] = u;
      dep[v] = dep[u] + 1;
      dfs1(v);
      siz[u] += siz[v];
      if (siz[v] > siz[G[u][0]]) {
        swap(v, G[u][0]);
      }
    }
  }
  void dfs2(int u, int x) {
    in[u] = cur++;
    seq[in[u]] = u;
    top[u] = x;
    for (auto v : G[u]) {
      dfs2(v, v == G[u][0] ? x : v);
    }
    out[u] = cur;
  }
  int lca(int u, int v) {
    while (top[u] != top[v]) {
      if (dep[top[u]] > dep[top[v]]) {
        u = par[top[u]];
      } else {
        v = par[top[v]];
      }
    }
    return dep[u] < dep[v] ? u : v;
  }
  int dist(int u, int v) {
    return dep[u] + dep[v] - 2 * dep[2 * lca(u, v)];
  }
  bool on_path(int p, int u, int v) {
    return (is_ancester(p, u) || is_ancester(p, v)) && dep[p] >= dep[lca(u, v)];
  }
  int jump(int u, int k) {
    if (dep[u] < k) {
      return -1;
    }
    int d = dep[u] - k;
    while (dep[top[u]] > d) {
      u = par[top[u]];
    }
    return seq[in[u] + d - dep[u]];
  }
  bool is_ancester(int u, int v) {
    return in[u] <= in[v] && in[v] < out[u];
  }
  int findChild(int u, int v) {
    assert(u != v);
    if (!is_ancester(u, v)) {
      return par[u];
    }
    auto it = upper_bound(G[u].begin(), G[u].end(), v, [&](int x, int y) {
      return in[x] < in[y];
    }) - 1;
    return *it;
  }
  int lca(int u, int v, int w) {
    u = min({in[u], in[v], in[w]});
    v = max({in[u], in[v], in[w]});
    return lca(seq[u], seq[v]);
  }
};

vector<int> dfn, qr;
struct cmp {
  bool operator()(int u, int v) const {
    return (dfn[qr[u]] != dfn[qr[v]]) ? dfn[qr[u]] < dfn[qr[v]] : u < v;
  }
};

void solve() {
  int n, m, Q;
  cin >> n >> m >> Q;
  vector<LL> R(m + 1), V(m + 1);
  vector vec(n, vector<int>());
  for (int i = 0; i < m; i++) {
    cin >> R[i] >> V[i];
    R[i]--;
    vec[R[i]].emplace_back(i);
  }
  int rt = m;
  Tree tr(m + 1);
  {
    V[rt] = 2e9;
    vector<int> st{m};
    for (int i = 0; i < m; i++) {
      while (1) {
        int u = st.back();
        if (V[u] > V[i]) {
          tr.addEdge(u, i);
          break;
        }
        st.pop_back();
      }
      st.push_back(i);
    }
    tr.init(rt);
  }
  auto &top = tr.top;
  auto &dep = tr.dep;
  auto &par = tr.par;
  auto &siz = tr.siz;
  auto &dfn = tr.in;
  auto &seq = tr.seq;
  auto &G = tr.G;
  // cerr << "max_dep: " << *max_element(dep.begin(), dep.end()) << "\n";
  vector chain(m + 1, vector<int>());
  {
    for (int i = 0; i <= m; i++) {
      int u = tr.seq[i];
      chain[top[u]].emplace_back(u);
    }
    // for (int i = 0; i <= m; i++) {
    //   cerr << "chain " << i << "\n";
    //   for (auto u : chain[i]) {
    //     cerr << u << " ";
    //   }
    //   cerr << "\n";
    // }
  }
  vector<int> ql(Q), qr(Q);
  for (int i = 0; i < Q; i++) {
    cin >> ql[i] >> qr[i], ql[i]--, qr[i]--;
  }
  ::dfn = dfn, ::qr = qr;
  vector s(m + 1, set<int, cmp>());
  vector st(Q, stack<pair<int, int>>());
  for (int i = 0; i < Q; i++) {
    int u = qr[i];
    // cerr << "test " << i << " " << u << "\n";
    while (1) {
      if (top[u] != m && top[u] >= ql[i]) {
        // cerr << "path " << top[u] << " " << u << "\n";
        st[i].emplace(top[u], u);
        u = top[u];
        if (par[u] != -1 && par[u] != m && par[u] >= ql[i]) {
          u = par[u];
        } else {
          break;
        }
      } else {
        int l = dep[top[u]] + 1, r = dep[u], bas = dep[top[u]];
        while (l < r) {
          int mid = (l + r) / 2;
          int v = chain[top[u]][mid - bas];
          if (v >= ql[i] && v != m) r = mid;
          else l = mid + 1;
        }
        // cerr << "path " << chain[top[u]][l - bas] << " " << u << "\n";
        st[i].emplace(chain[top[u]][l - bas], u);
        u = chain[top[u]][l - bas];
        break;
      }
    }
    // cerr << "! " << u << "\n";
    s[u].emplace(i);
  }
  vector<int> fl(m + 1);
  vector<LL> ans(Q), b(m + 1), a = V;
  DSU dsu(m + 1);
  auto find = [&](int u) {
    int x = u;
    while (1) {
      x = dsu.find(x);
      if (fl[x]) {
        if (!G[x].size()) {
          x = -1;
          break;
        }
        dsu.merge(x, G[x][0]);
      } else {
        break;
      }
    }
    return x;
  };
  for (int t = 0; t < n; t++) {
    auto split = [&](auto &s, int tar) {
      vector<int> ouf;
      // cerr << "nmsl " << tar << "\n";
      // for (auto x : s) {
        // cerr << x << " " << dfn[qr[x]] << " " << dfn[tar] << "\n";
      // }
      if (tar == -1) {
        ouf = vector(s.begin(), s.end());
        s.clear();
      } else {
        auto l = s.begin();
        // if (s.size() == 0) {
        //   cerr << "none" << "\n";
        // } else {
        //   cerr << "fuck " << *s.begin() << "\n";
        //   for (auto x : s) {
        //     cerr << x << " " << dfn[qr[x]] << "\n";
        //   }
        // }
        while (l != s.end()) {
          int x = *l;
          if (dfn[qr[x]] < dfn[tar]) {
            // cerr << "split " << x << "\n";
            ouf.emplace_back(x);
            l = s.erase(l);
          } else {
            break;
          }
        }
        while (l != s.end()) {
          int x = *l;
          if (dfn[qr[x]] < dfn[tar] + siz[tar]) {
            l++;
          } else {
            break;
          }
        }
        while (l != s.end()) {
          int x = *l;
          // cerr << "split " << x << "\n";
          ouf.emplace_back(x);
          l = s.erase(l);
        }
      }
      return ouf;
    };
    auto merge = [&](int u, int v) {
      auto &S = s[u];
      auto &T = s[v];
      LL &b1 = b[u], &b2 = b[v], &a1 = a[u], &a2 = a[v];
      // cerr << "merge " << u << " " << v << "\n";
      // for (auto x : S) {
      //   cerr << x << " ";
      // }
      // cerr << "\n";
      // for (auto x : T) {
      //   cerr << x << " ";
      // }
      // cerr << "\n";
      bool swp = false;
      if (S.size() > T.size()) {
        swap(S, T);
        swap(b1, b2);
        swap(a1, a2);
        swp = true;
      }
      for (auto x : S) {
        ans[x] += b1 - b2 + (a1 - a2) * (t + 1);
        T.emplace(x);
      }
      if (swp) {
        b2 += (a2 - a1) * (t + 1);
        swap(a1, a2);
      }
    };
    auto drop = [&](int o, int x) {
      int u = o, tar = -1;
      while (st[x].size()) {
        auto [_, y] = st[x].top();
        if (dep[u] > dep[y]) {
          st[x].pop();
        } else {
          if (dep[u] < dep[_]) u = _;
          int v = find(u);
          if (v != -1 && dep[y] >= dep[v]) {
            tar = v;
            break;
          } else {
            st[x].pop();
          }
        }
      }
      // cerr << "test_drop " << o << " " << x << " " << tar << "\n";
      // cerr << a[o] << " " << b[o] << " " << a[tar] << " " << b[tar] << "\n";
      if (tar == -1) {
        ans[x] += a[o] * (t + 1) + b[o];
      } else {
        s[tar].emplace(x);
        ans[x] += (a[o] - a[tar]) * (t + 1) + b[o] - b[tar];
      }
    };
    auto ban = [&](int u) {
      // cerr << "ban " << t << " " << u << "\n";
      fl[u] = 1;
      int tar = find(u);
      // cerr << "tar " << tar << "\n";
      // for (auto x : s[u]) cerr << "has " << x << "\n";
      auto bf = split(s[u], tar);
      for (auto x : bf) {
        // cerr << "drop " << x << "\n";
        drop(u, x);
      }
      if (~tar) {
        merge(u, tar);
      }
    };
    for (auto u : vec[t]) {
      ban(u);
    }
  }
  LL xorSum = 0;
  for (int i = 0; i < Q; i++) {
    xorSum ^= ans[i];
  }
  cout << xorSum << "\n";
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}