#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T read() { T x; return cin >> x, x; }
template <class T> T cmax(T &x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T &x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

void Main() {
  int n, m, V;
  cin >> n >> m >> V;
  vector<pair<int, int>> p;
  {
    int tmp = V;
    for (int i = 2; i * i <= tmp; i++) {
      if (tmp % i == 0) {
        int c = 0;
        while (tmp % i == 0) ++c, tmp /= i;
        p.eb(i, c);
      }
    }
    if (tmp > 1) p.eb(tmp, 1);
  }
  int K = SZ(p);
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  vector G(n, vector<pair<int, int>>());
  for (int i = 0; i < m; i++) {
    int u = read<int>() - 1, v = read<int>() - 1, w = read<int>();
    G[u].eb(v, w);
    G[v].eb(u, w);
  }
  {
    int tmp = a[0];
    for (auto [x, c] : p) {
      while (tmp % x == 0) tmp /= x;
    }
    assert(tmp == 1);
  }
  vector<int> mask(n);
  for (int i = 0; i < n; i++) {
    int tmp = a[i], s = 0, cur = 0;
    for (auto [x, c] : p) {
      int d = 0;
      while (tmp % x == 0) ++d, tmp /= x;
      if (d <= c) {
        s |= 1 << cur; 
      }
      cur++;
    }
    mask[i] = s;
  }
  const LL Inf = 1e18;
  vector d(n, vector<LL>(1 << K, Inf));
  vector vis(n, vector<int>(1 << K));
  d[0][mask[0]] = 0;
  priority_queue<tuple<LL, int, int>> q;
  q.emplace(0, 0, mask[0]);
  while (SZ(q)) {
    auto [_, u, s] = q.top();
    q.pop();
    if (vis[u][s]) continue;
    vis[u][s] = 1;
    if (s == (1 << K) - 1) {
      cout << d[u][s] << "\n";
      return;
    }
    for (auto [v, w] : G[u]) {
      int t = s | mask[v];
      if (d[v][t] > d[u][s] + w) {
        cmin(d[v][t], d[u][s] + w);
        q.emplace(-d[v][t], v, t);
      }
    }
  }
  cout << -1 << "\n";
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}