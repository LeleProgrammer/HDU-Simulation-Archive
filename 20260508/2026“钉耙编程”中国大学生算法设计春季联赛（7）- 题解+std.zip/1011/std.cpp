#include <bits/stdc++.h>
using namespace std;

using LL = long long;

void solve() {
  int n, K;
  cin >> n >> K;
  int P = gcd(n, K);
  string s;
  cin >> s;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    a[i] = s[i] - '0';
  }
  vector<int> f(P);
  for (int i = 0; i < n; i++) {
    int j = (n - i - 1);
    if (i > j) break;
    int u = i % P, v = j % P;
    if (u > v) swap(u, v);
    if (a[i] != a[j]) f[u] ^= 1;
  }
  if (n % 2) {
    f[n / 2 % P] = 0;
  }
  if (count(f.begin(), f.end(), 1) == 0) {
    cout << "YES" << "\n"; 
  } else {
    cout << "NO" << "\n";
  }
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}