#include <bits/stdc++.h>
using namespace std;

using LL = long long;

constexpr int P = 998244353;
template<class T> T qp(T a, LL b) {
  T c{1};
  while (b) {
    if (b & 1) c *= a;
    a *= a;
    b /= 2;
  }
  return c;
}
struct Mint {
  int v;
  Mint(LL x = 0) : v(x % P) {v += v >> 31 & P;}
  int val() const {return v;}
  Mint operator-() const {return -v;}
  Mint &operator+=(const Mint &b) {
    v += b.v - P, v += v >> 31 & P;
    return *this;
  }
  Mint &operator-=(const Mint &b) {
    v -= b.v, v += v >> 31 & P;
    return *this;
  }
  Mint &operator*=(const Mint &b) {
    v = LL(v) * b.v % P;
    return *this;
  }
  Mint &operator/=(const Mint &b) {
    return *this *= b.inv();
  }
  friend Mint operator+(Mint a, const Mint &b) {return a += b;}
  friend Mint operator-(Mint a, const Mint &b) {return a -= b;}
  friend Mint operator*(Mint a, const Mint &b) {return a *= b;}
  friend Mint operator/(Mint a, const Mint &b) {return a /= b;}
  Mint inv() const {
    return qp(*this, P - 2);
  }
  friend istream &operator>>(istream &is, Mint &a) {
    LL v;
    is >> v;
    a = Mint(v);
    return is;
  }
  friend ostream &operator<<(ostream &os, const Mint &a) {
    return os << a.v;
  }
};

vector<Mint> fac, ifac, inv;
void comb(int n) {
  fac.resize(n + 1);
  ifac.resize(n + 1);
  inv.resize(n + 1);
  fac[0] = 1;
  for (int i = 1; i <= n; i++) {
    fac[i] = fac[i - 1] * i;
  }
  ifac[n] = fac[n].inv();
  for (int i = n; i; i--) {
    ifac[i - 1] = ifac[i] * i;
    inv[i] = ifac[i] * fac[i - 1];
  }
}
Mint binom(int n, int m) {
  if (n < m || m < 0) return 0;
  return fac[n] * ifac[m] * ifac[n - m];
}

void Main() {
  int n;
  cin >> n;
  auto dp = [&](int lim) {
    vector<Mint> f(n + 1), g(n + 1);
    f[0] = 1;
    for (int i = 0; i < n; i++) {
      fill(g.begin(), g.end(), 0);
      for (int j = 0; j <= lim; j++) {
        g[j] += f[j] * (j ? 2 : 1);
        if (j + 1 <= lim) g[j] += f[j + 1];
        if (j - 1 >= 0) g[j] += f[j - 1];
      }
      swap(f, g);
    }
    return f[0] + f[1];
  };
  for (int k = 1; k <= n; k++) {
    cout << dp(k) << " \n"[k == n];
  }
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}