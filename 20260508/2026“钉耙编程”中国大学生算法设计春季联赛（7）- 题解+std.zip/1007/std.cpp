#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T rd() { T x; return cin >> x, x; }
template <class T> T cmax(T& x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T& x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

struct DSU {
  vector<int> f, s;
  DSU(int n) : f(n), s(n, 1) { iota(ALL(f), 0); }
  int find(int u) {
    while (u != f[u]) u = f[u] = f[f[u]];
    return u;
  }
  bool merge(int u, int v) {
    u = find(u), v = find(v);
    if (u == v) return 0;
    s[v] += s[u], f[u] = v;
    return 1;
  }
  bool same(int u, int v) { return find(u) == find(v); }
};

void Main() {
  int n;
  cin >> n;
  vector<int> a(n);
  vector<int> b(2 * n - 1);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    b[2 * i] = a[i] + a[i];
  }
  for (int i = 0; i + 1 < n; i++) {
    b[i + i + 1] = a[i] + a[i + 1];
  }
  vector<int> o(2 * n - 1);
  iota(ALL(o), 0);
  sort(ALL(o), [&](int x, int y) {
    return b[x] < b[y];
  });
  DSU dsu(n);
  LL ans = 0;
  for (int i : o) {
    for (int j = 0; j <= i; j++) {
      int k = i - j;
      if (j < n && k < n) {
        if (dsu.merge(j, k)) {
          ans += b[i];
        }
      }
    }
  }
  cout << ans << "\n";
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}