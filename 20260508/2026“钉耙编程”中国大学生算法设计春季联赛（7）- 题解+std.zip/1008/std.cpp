#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T rd() { T x; return cin >> x, x; }
template <class T> T cmax(T& x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T& x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

constexpr int P = 998244353;
template<class T> T qp(T a, LL b = P - 2) {
  T c = 1;
  for (; b; b >>= 1, a *= a) if (b & 1) c *= a;
  return c;
}
struct Z {
  LL v;
  Z(LL x = 0) : v(x % P) { (v += P) %= P; }
  Z operator-() const { return -v; }
  int val() const { return v; }
  Z &operator+=(const Z& b) { return (v += b.v) %= P, *this; }
  Z &operator-=(const Z& b) { return (v += P - b.v) %= P, *this; }
  Z &operator*=(const Z& b) { return (v *= b.v) %= P, *this; }
  Z &operator/=(const Z& b) { return *this *= qp(b, P - 2); }
  friend Z operator+(Z a, const Z& b) { return a += b; }
  friend Z operator-(Z a, const Z& b) { return a -= b; }
  friend Z operator*(Z a, const Z& b) { return a *= b; }
  friend Z operator/(Z a, const Z& b) { return a /= b; }
  friend ostream &operator<<(ostream &os, const Z& a) { return os << a.v; }
};

void Main() {
  int n;
  cin >> n;
  vector<Z> a(n), b(n);
  for (int i = 0; i < n; i++) a[i] = rd<int>();
  for (int i = 0; i < n; i++) b[i] = rd<int>();
  Z S = accumulate(ALL(a), Z(0));
  vector<Z> s(n + 1);
  for (int i = 0; i < n; i++) s[i + 1] = s[i] + b[i];
  Z ans;
  for (int i = 0; i < n; i++) {
    ans += a[i] * b[i] / 2 + a[i] * s[i];
  }
  cout << ans / S << "\n";
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}