#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T rd() { T x; return cin >> x, x; }
template <class T> T cmax(T& x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T& x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

template <LL B, LL P>
struct haxi {
  vector<LL> h, p;
  haxi(const string& s) : h(SZ(s) + 1), p(SZ(s) + 1, 1) {
    for (int i = 0; i < SZ(s); i++) {
      h[i + 1] = (h[i] * B + s[i]) % P;
      p[i + 1] = (p[i] * B) % P;
    }
  }
  LL get(int l, int r) {
    LL res = (h[r + 1] - h[l] * p[r - l + 1]) % P;
    return res < 0 ? res + P : res;
  }
};
struct Haxi {
  haxi<19260817, 917120411> h1;
  haxi<19491001, 666623333> h2;
  Haxi(const string& s) : h1(s), h2(s) {}
  pair<LL, LL> get(int l, int r) {
    return {h1.get(l, r), h2.get(l, r)};
  }
};

const int M = 25;

struct pair_hash {
  template <class T1, class T2>
  size_t operator()(const pair<T1, T2>& p) const {
    auto h1 = hash<T1>{}(p.first);
    auto h2 = hash<T2>{}(p.second);
    return h1 ^ (h2 + 0x9e3779b9 + (h1 << 6) + (h1 >> 2));
  }
};

unordered_map<pair<LL, LL>, int, pair_hash> h[M][M];

void Main() {
  int n, m, Q;
  cin >> n >> m >> Q;
  vector<int> p(n);
  vector<string> s(n);
  for (int i = 0; i <= m; i++) {
    for (int j = i; j <= m; j++) {
      h[i][j].clear();
    }
  }
  vector<Haxi> ha;
  for (int i = 0; i < n; i++) {
    cin >> p[i] >> s[i], p[i]--;
    ha.eb(Haxi(s[i]));
    for (int l = 0; l < SZ(s[i]); l++) {
      for (int r = l; r < SZ(s[i]); r++) {
        h[p[i] + l][p[i] + r][ha[i].get(l, r)]++;
      }
    }
  }
  while (Q--) {
    int op = rd<int>();
    if (op == 1) {
      int i = rd<int>() - 1, d = rd<int>();
      for (int l = 0; l < SZ(s[i]); l++) {
        for (int r = l; r < SZ(s[i]); r++) {
          h[p[i] + l][p[i] + r][ha[i].get(l, r)]--;
        }
      }
      p[i] += d;
      for (int l = 0; l < SZ(s[i]); l++) {
        for (int r = l; r < SZ(s[i]); r++) {
          h[p[i] + l][p[i] + r][ha[i].get(l, r)]++;
        }
      }
    } else {
      int i = rd<int>() - 1, ans = 0;
      for (int l = 0; l < SZ(s[i]); l++) {
        for (int r = l; r < SZ(s[i]); r++) {
          int c = h[p[i] + l][p[i] + r][ha[i].get(l, r)];
          if (c > 1) cmax(ans, r - l + 1);
        }
      }
      cout << ans << "\n";
    }
  }
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}