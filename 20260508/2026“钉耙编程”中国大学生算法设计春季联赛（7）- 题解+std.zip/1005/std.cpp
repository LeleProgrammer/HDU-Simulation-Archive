#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T rd() { T x; return cin >> x, x; }
template <class T> T cmax(T& x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T& x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

void Main() {
  int n, k;
  cin >> n >> k;
  vector<LL> a(n), s(n + 1);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    s[i + 1] = s[i] + a[i];
  }
  if (k > n / 2) {
    LL res = 0;
    for (int i = 0, j = n - 1, v = k; i <= j; i++, j--, v--) {
      res += a[i] + v + (i == j ? 0 : a[j] + v);
    }
    cout << res << "\n";
  } else {
    vector<LL> mx(n + 1);
    for (int i = 0; i < n; i++) {
      mx[i + 1] = max(mx[i], (i >= k - 1 ? s[i + 1] - s[i - k + 1] : 0));
    }
    LL ans = 0;
    for (int i = 0; i + k - 1 < n; i++) {
      cmax(ans, s[i + k] - s[i] + mx[i] + LL(1 + k) * k);
    }
    cout << ans << "\n";
  }
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}