#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())

void Main() {
  int n;
  cin >> n;
  vector a(n, vector<int>(n));
  vector row(n * n, vector<int>());
  vector col(n * n, vector<int>());
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cin >> a[i][j];
      a[i][j]--;
      row[a[i][j]].emplace_back(i);
      col[a[i][j]].emplace_back(j);
    }
  }
  vector<int> ans;
  for (int i = 0; i < n * n; i++) {
    auto &r = row[i], &c = col[i];
    sort(ALL(r)), r.erase(unique(ALL(r)), r.end());
    sort(ALL(c)), c.erase(unique(ALL(c)), c.end());
    if (SZ(r) == n && SZ(c) == n) {
      ans.emplace_back(i);
    }
  }
  cout << SZ(ans) << "\n";
  for (int i = 0; i < SZ(ans); i++) {
    cout << ans[i] + 1 << " \n"[i == SZ(ans) - 1];
  }
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}