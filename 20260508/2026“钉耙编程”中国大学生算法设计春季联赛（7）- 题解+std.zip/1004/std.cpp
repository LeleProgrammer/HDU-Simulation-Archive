#include <bits/stdc++.h>
using namespace std;

using LL = long long;
const LL INF = 1e18;

template <class T> void cmax(T& x, const T& y) { x = max(x, y); }

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t;
  cin >> t;
  while (t--) {
    int n;
    cin >> n;
    vector<LL> a(n + 1);
    for (int i = 0; i <= n; i++) cin >> a[i];
    vector dp(n + 1, array<LL, 3>{-INF, -INF, -INF});
    dp[0][0] = 0;
    for (int i = 0; i < n; i++) {
      auto ndp = vector(n + 1, array<LL, 3>{-INF, -INF, -INF});
      for (int j = 0; j <= n; j++) {
        for (int k : {0, 1, 2}) {
          if (dp[j][k] == -INF) continue;
          if (j + 1 <= n) cmax(ndp[j + 1][min(k + 1, 2)], dp[j][k] - a[i]);
          if (j && (k < 2 || a[i - 2] > a[i - 1])) cmax(ndp[j - 1][0], dp[j][k] + a[i]);
        }
      }
      swap(dp, ndp);
    }
    LL ans = -INF;
    for (int j = 0; j <= n; j++) {
      for (int k : {0, 1, 2}) {
        ans = max(ans, dp[j][k] + a[n] * j);
      }
    }
    cout << ans << "\n";
  }
  return 0;
}