#include <bits/stdc++.h>
using namespace std;

#define ALL(s) s.begin(), s.end()
#define SZ(s) int(s.size())
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define eb emplace_back

using LL = long long;
using ULL = unsigned long long;
using I = __int128;

ULL seed = chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rnd(seed);

template <class T> T rd() { T x; return cin >> x, x; }
template <class T> T cmax(T& x, const T& y) { return x = max(x, y); }
template <class T> T cmin(T& x, const T& y) { return x = min(x, y); }

template <class... Args>
void RS(int n, Args&... args) { (args.resize(n), ...); }

template <class T>
struct BIT {
  int n;
  vector<T> a;
  BIT(int n = 0) : n(n), a(n + 1) {}
  void mdf(int p, T v) {
    for (int i = p + 1; i <= n; i += i & -i) {
      a[i] += v;
    }
  }
  T qry(int p) {
    T r{};
    for (int i = p; i > 0; i -= i & -i) {
      r += a[i];
    }
    return r;
  }
  T sum(int l, int r) { // [l, r)
    return qry(r) - qry(l);
  }
};

void Main() {
  int n, m;
  cin >> n >> m;
  vector G(n, vector<pair<int, int>>());
  for (int i = 0; i < n - 1; i++) {
    int u = rd<int>() - 1, v = rd<int>() - 1, w = rd<int>();
    G[u].eb(v, w);
    G[v].eb(u, w);
  }
  vector<int> vis(n);
  for (int i = 0; i < m; i++) {
    vis[rd<int>() - 1] = 1;
  }
  int ti = 0;
  vector<int> fa(n, -1), fv(n, 0), dfn(n), siz(n);
  BIT<int> ds(n);
  auto dfs = [&](auto _, int u, int f, int x)->void {
    dfn[u] = ti++;
    siz[u] = 1;
    if (f != -1) {
      G[u].erase(find(ALL(G[u]), pair<int, int>{f, fv[u]}));
      if (!SZ(G[u]) || vis[u]) {
        ds.mdf(dfn[u], 1);
        ds.mdf(dfn[x], -1);
      }
    }
    for (auto [v, w] : G[u]) {
      fv[v] = w;
      _(_, v, u, vis[u] ? u : x);
      siz[u] += siz[v];
    }
  };
  assert(vis[0]);
  dfs(dfs, 0, -1, -1);
  LL ans = 0;
  for (int i = 1; i < n; i++) {
    int c = ds.sum(dfn[i], dfn[i] + siz[i]);
    ans += LL(fv[i]) * max(0, c - 1);
  }
  cout << ans << "\n";
}

int main() {
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--) Main();
  return 0;
}