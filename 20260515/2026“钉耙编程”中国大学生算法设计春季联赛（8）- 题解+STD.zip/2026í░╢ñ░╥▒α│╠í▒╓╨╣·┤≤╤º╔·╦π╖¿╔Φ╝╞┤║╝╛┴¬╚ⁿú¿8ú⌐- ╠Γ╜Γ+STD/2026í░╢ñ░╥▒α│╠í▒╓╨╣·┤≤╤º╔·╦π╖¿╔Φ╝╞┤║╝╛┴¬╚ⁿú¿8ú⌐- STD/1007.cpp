#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

// 辅助函数：计算 |x|^3 mod MOD
ll calc3(ll x) {
    ll abs_x = std::abs(x) % MOD;
    return abs_x * abs_x % MOD * abs_x % MOD;
}

// 辅助函数：计算 x * |x| mod MOD (保留符号的平方)
ll signed_sq(ll x) {
    ll val = x % MOD;
    ll abs_x = std::abs(x) % MOD;
    return val * abs_x % MOD;
}

void init(){
}

void solve(){
    int n;
    std::cin >> n;
    ll prev_L, prev_R;
    std::cin >> prev_L >> prev_R;
    ll ans = 0;
    for(int i = 2; i <= n; i++){
        ll curr_L, curr_R;
        std::cin >> curr_L >> curr_R;
        ll A = prev_L, B = prev_R;
        ll C = curr_L, D = curr_R;
        ll len1 = B - A;
        ll len2 = D - C;
        ll expected_val = 0;
        if (len1 == 0 && len2 == 0) {
            expected_val = std::abs(A - C) % MOD;
        } else if (len1 == 0) {
            ll num = (signed_sq(D - A) - signed_sq(C - A)) % MOD;
            ll den = 2LL * len2 % MOD;
            expected_val = num * qpow(den, MOD - 2) % MOD;
        } else if (len2 == 0) {
            ll num = (signed_sq(B - C) - signed_sq(A - C)) % MOD;
            ll den = 2LL * len1 % MOD;
            expected_val = num * qpow(den, MOD - 2) % MOD;
        } else {
            ll num = (calc3(A - D) + calc3(B - C) - calc3(A - C) - calc3(B - D)) % MOD;
            ll den = 6LL * (len1 % MOD) % MOD * (len2 % MOD) % MOD;
            expected_val = num * qpow(den, MOD - 2) % MOD;
        }

        expected_val = (expected_val % MOD + MOD) % MOD;
        ans = (ans + expected_val) % MOD;

        prev_L = curr_L;
        prev_R = curr_R;
    }

    std::cout << ans << '\n';
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}