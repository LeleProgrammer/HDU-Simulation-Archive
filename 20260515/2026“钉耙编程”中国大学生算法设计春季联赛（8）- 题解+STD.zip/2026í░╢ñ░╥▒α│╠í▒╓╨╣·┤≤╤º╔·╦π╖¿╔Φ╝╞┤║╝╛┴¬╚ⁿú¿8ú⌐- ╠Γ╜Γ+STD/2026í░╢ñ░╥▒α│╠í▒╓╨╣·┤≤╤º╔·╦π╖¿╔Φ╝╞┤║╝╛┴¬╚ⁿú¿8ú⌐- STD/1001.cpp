#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 2e5 + 5; //
typedef long long ll;
const int INF = 2e9;
int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

void init(){
}

void solve(){
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> adj(n + 1);
    for(int i = 0; i < m; i++){
        int u, v;
        std::cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    std::vector<int> d1(n + 1, -1), dn(n + 1, -1);
    auto dij = [&](int s, std::vector<int>& d) {
        std::queue<int> q;
        d[s] = 0;
        q.push(s);
        while(!q.empty()){
            int u = q.front();
            q.pop();
            for(int v : adj[u]){
                if(d[v] == -1){
                    d[v] = d[u] + 1;
                    q.push(v);
                }
            }
        }
    };

    dij(1, d1);
    dij(n, dn);

    int d = d1[n];
    std::vector<bool> in(n + 1, false);
    for(int i = 1; i <= n; i++){
        if(d1[i] != -1 && dn[i] != -1 && d1[i] + dn[i] == d){
            in[i] = true;
        }
    }
    std::vector<int> dist(n + 1, 1e9);
    std::queue<int> q;
    dist[n] = 0;
    q.push(n);

    while(!q.empty()){
        int u = q.front();
        q.pop();
        int t = dist[u];

        for(int v : adj[u]){
            int tt = t + 1;
            bool f = false;
            if(in[v]){
                if(tt < d1[v]) f = true;
            } else {
                if(tt <= d1[v]) f = true;
            }

            if(f && tt < dist[v]){
                dist[v] = tt;
                q.push(v);
            }
        }
    }

    int ans = INF;

    for(int u = 1; u <= n; u++){
        if(dist[u] == 1e9) continue;
        for(int v : adj[u]){
            if(in[u]){
                int tt = dist[u] + 1;
                if(tt > d1[v]){
                    bool f = (in[v] && d1[v] == d1[u] - 1 && dist[u] == d1[v]);
                    if(!f){
                        ans = std::min(ans, tt + d1[v]);
                    }
                }
            } else {
                int tt = std::max(dist[u] + 1, d1[v] + 1);
                ans = std::min(ans, tt + d1[v]);
            }
        }
    }
    if(ans < 2 * d){
        std::cout << "Kasumi " << ans << '\n';
    } else {
        std::cout << "Arisa\n";
    }
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}