// #pragma GCC optimize("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#include<bits/stdc++.h>

const int MOD = 1e9 + 7; 
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 2e5 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

const double PI = acos(-1.0);
struct Complex {
    double x, y;
    Complex(double _x = 0.0, double _y = 0.0) : x(_x), y(_y) {}
    Complex operator-(const Complex &b) const { return Complex(x - b.x, y - b.y); }
    Complex operator+(const Complex &b) const { return Complex(x + b.x, y + b.y); }
    Complex operator*(const Complex &b) const { return Complex(x * b.x - y * b.y, x * b.y + y * b.x); }
};

int rev[1 << 20];
Complex w[1 << 20];

void init_fft(int n) {
    for (int i = 0; i < n; i++) {
        rev[i] = (rev[i >> 1] >> 1) | ((i & 1) ? (n >> 1) : 0);
    }
    for (int i = 0; i < n / 2; i++) {
        w[n / 2 + i] = Complex(cos(2 * PI * i / n), sin(2 * PI * i / n));
    }
    for (int i = n / 2 - 1; i >= 1; i--) {
        w[i] = w[i << 1];
    }
}

void fft(std::vector<Complex>& a, int n, int opt) {
    for (int i = 0; i < n; i++) if (i < rev[i]) std::swap(a[i], a[rev[i]]);
    for (int k = 1; k < n; k <<= 1) {
        for (int i = 0; i < n; i += (k << 1)) {
            for (int j = 0; j < k; j++) {
                Complex x = a[i + j];
                Complex W = w[k + j];
                if (opt == -1) W.y = -W.y;
                Complex y = a[i + j + k] * W;
                a[i + j] = x + y;
                a[i + j + k] = x - y;
            }
        }
    }
    if (opt == -1) {
        for (int i = 0; i < n; i++) {
            a[i].x /= n;
        }
    }
}

void init(){
}

void solve(){
    int n;
    std::cin >> n;
    std::vector<int> a(n);
    for(int i = 0; i < n; i++) std::cin >> a[i];
    int L = 1;
    while(L <= 2 * n) L <<= 1;
    init_fft(L);
    int B = std::min(n, std::max(2000, n / 30));
    int M = (n + B - 1) / B;
    std::vector<ll> ans(n + 1, 0);
    if(M > 1) {
        std::vector<Complex> R(L, Complex(0, 0));
        std::vector<Complex> SumQ(L, Complex(0, 0));
        for(int b = M - 1; b >= 0; b--) {
            int l = b * B;
            int r = std::min(n, l + B);
            std::vector<Complex> P(L, Complex(0, 0));
            std::vector<Complex> Q(L, Complex(0, 0));
            for(int i = l; i < r; i++){
                P[a[i]].x += 1.0;
                Q[n - a[i]].x += 1.0;
            }
            fft(P, L, 1);
            fft(Q, L, 1);
            for(int k = 0; k < L; k++){
                R[k] = R[k] + P[k] * SumQ[k];
                SumQ[k] = SumQ[k] + Q[k];
            }
        }
        fft(R, L, -1);
        for(int k = 0; k <= n; k++){
            ans[k] += (ll)(R[n + k].x + 0.5);
        }
    }

    for(int b = 0; b < M; b++){
        int l = b * B;
        int r = std::min(n, l + B);
        for(int i = l; i < r; i++){
            for(int j = i + 1; j < r; j++){
                if(a[i] >= a[j]){
                    ans[a[i] - a[j]]++;
                }
            }
        }
    }

    for(int k = 0; k <= n; k++){
        std::cout << ans[k] << (k == n ? "" : " ");
    }
    std::cout << '\n';
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}