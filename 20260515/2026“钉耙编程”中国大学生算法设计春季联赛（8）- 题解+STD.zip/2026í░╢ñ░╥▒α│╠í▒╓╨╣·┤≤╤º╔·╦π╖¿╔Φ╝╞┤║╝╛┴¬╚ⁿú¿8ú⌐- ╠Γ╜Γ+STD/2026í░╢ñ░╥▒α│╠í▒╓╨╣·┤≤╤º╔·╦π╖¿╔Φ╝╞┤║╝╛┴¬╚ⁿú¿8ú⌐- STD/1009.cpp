#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

void init(){
}
void solve(){
    std::string s;
    std::cin >> s;
    int ans = 0, mu = 0, mo = 0, w = 0;
    for(char c : s){
        if(c == 'R'){
            if(mu > 0){
                mu--;
                mo++;
            } else if(w > 0){
                w--;
                mo++;
            } else {
                ans++;
                mo++;
            }
        } else if(c == 'B'){
            if(mo > 0){
                mo--;
                mu++;
            } else if(w > 0){
                w--;
                mu++;
            } else {
                ans++;
                mu++;
            }
        } else if(c == 'W'){
            if(ans == 0){
                ans = 1;
            }
            w = ans;
            mu = 0;
            mo = 0;
        }
    }

    std::cout << ans << '\n';
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}