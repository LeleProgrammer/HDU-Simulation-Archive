#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 1e6 + 5; // 根据题目最大值范围10^6
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

// 预处理所需的数组
int primes[N], cnt;
bool st[N];
int mu[N];
int inv[N], invsq[N];
int F[N];

void init(){
    mu[1] = 1;
    for (int i = 2; i < N; ++i) {
        if (!st[i]) {
            primes[cnt++] = i;
            mu[i] = -1;
        }
        for (int j = 0; primes[j] * i < N; ++j) {
            st[primes[j] * i] = true;
            if (i % primes[j] == 0) {
                mu[i * primes[j]] = 0;
                break;
            }
            mu[i * primes[j]] = -mu[i];
        }
    }
    
    inv[1] = 1;
    invsq[1] = 1;
    for (int i = 2; i < N; ++i) {
        inv[i] = 1LL * (MOD - MOD / i) * inv[MOD % i] % MOD;
        invsq[i] = 1LL * inv[i] * inv[i] % MOD;
    }
    
    for (int i = 1; i < N; ++i) {
        if (invsq[i] == 0) continue;
        for (int j = i; j < N; j += i) {
            if (mu[j / i] == 1) {
                F[j] = (F[j] + invsq[i]) % MOD;
            } else if (mu[j / i] == -1) {
                F[j] = (F[j] - invsq[i] + MOD) % MOD;
            }
        }
    }
}

int sumA[N], sumB[N];

void solve(){
    int n, m;
    std::cin >> n >> m;
    int max_val = 0;
    for(int i = 0; i < n; i++){
        int x;
        std::cin >> x;
        max_val = std::max(max_val, x);
        sumA[x] = (sumA[x] + x) % MOD;
    }
    
    for(int i = 0; i < m; i++){
        int x;
        std::cin >> x;
        max_val = std::max(max_val, x);
        sumB[x] = (sumB[x] + x) % MOD;
    }
    
    ll ans = 0;
    for(int T = 1; T <= max_val; T++){
        ll sA = 0, sB = 0;
        for(int i = T; i <= max_val; i += T){
            sA = (sA + sumA[i]) % MOD;
            sB = (sB + sumB[i]) % MOD;
        }
        if(sA > 0 && sB > 0){
            ll term = sA * sB % MOD;
            term = term * F[T] % MOD;
            ans = (ans + term) % MOD;
        }
    }
    
    std::cout << ans << '\n';

    for(int i = 0; i <= max_val; i++){
        sumA[i] = sumB[i] = 0;
    }
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init(); 
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}