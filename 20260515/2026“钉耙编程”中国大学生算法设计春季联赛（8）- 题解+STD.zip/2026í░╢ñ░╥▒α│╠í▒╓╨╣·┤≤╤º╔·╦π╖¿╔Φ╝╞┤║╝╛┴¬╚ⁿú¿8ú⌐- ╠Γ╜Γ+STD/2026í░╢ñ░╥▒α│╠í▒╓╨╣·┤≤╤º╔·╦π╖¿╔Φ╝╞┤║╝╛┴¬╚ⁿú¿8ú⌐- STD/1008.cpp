#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

void init(){
}

void solve(){
    ll a, b;
    std::cin >> a >> b;

    ll mn = std::min(a, b);
    ll mx = std::max(a, b);

    if (mn > 1) {
        std::cout << 1 << '\n';
    } else {
        if (mx == 1) {
            std::cout << 2 << '\n';
        } else if (mx == 2) {
            std::cout << 3 << '\n';
        } else {
            std::cout << 2 << '\n';
        }
    }
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}