#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

void init(){
    // 多组数据局部处理，全局初始化可留空
}

void solve(){
    int n;
    std::cin >> n;
    std::vector<ll> val(n + 1);
    for(int i = 1; i <= n; i++) {
        std::cin >> val[i];
    }

    std::string s;
    std::cin >> s;

    // 只有一个花朵时拿走后为空集，极差必然是 0
    if (n == 1) {
        std::cout << 0 << '\n';
        return;
    }

    std::vector<std::pair<ll, char>> a(n + 1);
    for(int i = 1; i <= n; i++){
        a[i] = {val[i], s[i - 1]};
    }

    // 根据美丽值排序
    std::sort(a.begin() + 1, a.end());

    // 记录排序后所有 'R' 的位置
    std::vector<int> R_pos;
    for(int i = 1; i <= n; i++){
        if(a[i].second == 'R') {
            R_pos.push_back(i);
        }
    }

    ll global_ans = 2e18;

    // 枚举拿走的那一朵花 (对应排序后的第 i 朵)
    for(int i = 1; i <= n; i++){
        int M = n - 1; // 剩下的花朵数量

        // 虚拟读取去掉第 i 朵之后的数组 B 的第 idx 个元素 (1-based)
        auto get_val = [&](int idx) -> ll {
            return idx < i ? a[idx].first : a[idx + 1].first;
        };

        // O(1) 获取去掉 i 之后，前缀和后缀最多能取多少个连续的 'G'
        int first_R = -1;
        if(!R_pos.empty()){
            if(R_pos.front() != i) first_R = R_pos.front();
            else if(R_pos.size() > 1) first_R = R_pos[1];
        }
        int P = M;
        if(first_R != -1){
            P = (first_R < i ? first_R : first_R - 1) - 1;
        }

        int last_R = -1;
        if(!R_pos.empty()){
            if(R_pos.back() != i) last_R = R_pos.back();
            else if(R_pos.size() > 1) last_R = R_pos[R_pos.size() - 2];
        }
        int S = M;
        if(last_R != -1){
            S = M - (last_R < i ? last_R : last_R - 1);
        }

        // Base case: SG 为空，SR 包含剩下的所有
        ll ans_i = get_val(M) - get_val(1);

        // 二分寻找最佳的前缀 G 长度
        int l = 1, r = P;
        while(l <= r){
            int mid = l + (r - l) / 2;
            ll f1 = (mid == 0) ? 0 : get_val(mid) - get_val(1);
            ll f2 = (mid == M) ? 0 : get_val(M) - get_val(mid + 1);
            ans_i = std::min(ans_i, std::max(f1, f2));
            if(f1 < f2) l = mid + 1;
            else r = mid - 1;
        }

        // 二分寻找最佳的后缀 G 长度
        l = 1; r = S;
        while(l <= r){
            int mid = l + (r - l) / 2;
            ll f1 = (mid == 0) ? 0 : get_val(M) - get_val(M - mid + 1);
            ll f2 = (mid == M) ? 0 : get_val(M - mid) - get_val(1);
            ans_i = std::min(ans_i, std::max(f1, f2));
            if(f1 < f2) l = mid + 1;
            else r = mid - 1;
        }

        // 更新全局最小极差
        global_ans = std::min(global_ans, ans_i);
    }

    std::cout << global_ans << '\n';
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}