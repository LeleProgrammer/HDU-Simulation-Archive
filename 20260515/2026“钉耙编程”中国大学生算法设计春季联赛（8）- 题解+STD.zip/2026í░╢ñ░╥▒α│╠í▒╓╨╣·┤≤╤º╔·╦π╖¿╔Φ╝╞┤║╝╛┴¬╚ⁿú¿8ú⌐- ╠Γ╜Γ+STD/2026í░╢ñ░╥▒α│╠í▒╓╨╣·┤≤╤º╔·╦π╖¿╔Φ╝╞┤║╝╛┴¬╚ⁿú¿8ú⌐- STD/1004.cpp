#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;
int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}
ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}
ll f[N][N];
void init(){
    for(int i=0;i<N;i++){
        f[0][i] = 1;
    }
    for (int i = 1; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            ll cur = 0;
            //C(m, 2) * ans[n-1][m-2]
            if (j >= 2) {
                ll c1 = 1LL * j * (j - 1) / 2 % MOD;
                cur = (cur + c1 * f[i - 1][j - 2]) % MOD;
            }
            //m(2n - 2m - 1) * ans[n-1][m-1]
            if (j >= 1) {
                ll c2 = (2LL * i - 2LL * j - 1) % MOD;
                if (c2 < 0) c2 += MOD;
                cur = (cur + 1LL * j * c2 % MOD * f[i - 1][j - 1]) % MOD;
            }
            //(2m^2 - 4mn + 3m + 2n^2 - 3n + 1) * ans[n-1][m]
            ll c3 = (2LL * j * j - 4LL * j * i + 3LL * j + 2LL * i * i - 3LL * i + 1) % MOD;
            c3 = (c3 % MOD + MOD) % MOD;
            cur = (cur + c3 * f[i - 1][j]) % MOD;

            f[i][j] = cur;
        }
    }
}
void solve(){
    int n , m;
    std::cin >> n >> m;
    if(n > m) std::swap(n,m);
    if(n==1&&m==1){
        std::cout << 1 << '\n';
        return;
    }
    std::cout << f[n][m] << '\n';
}
signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}