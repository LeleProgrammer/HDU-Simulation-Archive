#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;
 
int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}
 
ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}
 
void init(){
}
 
void solve(){
    std::string s;
    std::cin >> s;
    ll n = s.length();
    ll total = n * (n + 1) / 2;
 
    ll c0 = 0;
    ll c1 = 0; 
 
    ll len0 = 0; 
    ll len1 = 0; 
 
    for(char c : s){
        if(c == '0'){
            c0 += len1 * (len1 + 1) / 2;
            len1 = 0;
            len0++;
        } else {
            c1 += len0 * (len0 + 1) / 2;
            len0 = 0;
            len1++;
        }
    }
    c0 += len1 * (len1 + 1) / 2;
    c1 += len0 * (len0 + 1) / 2;
    ll ans = 2 * total - 2 * c0 - c1;
 
    std::cout << ans << '\n';
}
 
signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}