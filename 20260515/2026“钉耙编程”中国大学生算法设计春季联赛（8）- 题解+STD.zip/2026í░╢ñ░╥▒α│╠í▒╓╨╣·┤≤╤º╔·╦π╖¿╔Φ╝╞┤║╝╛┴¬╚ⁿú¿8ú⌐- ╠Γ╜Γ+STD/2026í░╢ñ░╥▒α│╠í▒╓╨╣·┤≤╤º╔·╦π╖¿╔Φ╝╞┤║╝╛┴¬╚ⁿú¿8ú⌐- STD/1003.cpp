#include<bits/stdc++.h>
const int MOD = 1e9 + 7;
//#define int long long
#define debug(x) std::cout<<x<<"--------------------------------------\n" ;
const int N = 5e3 + 5;
typedef long long ll;

int gcd(int a,int b){
    return b ? gcd(b,a%b) : a ;
}

ll qpow(int a,int k){
    ll res = 1 ;
    while (k){
        if(k&1) res = 1ll * res * a % MOD ;
        a = 1ll * a * a % MOD ;
        k >>= 1 ;
    }
    return res ;
}

void init(){
}

void solve(){
    int n;
    ll x;
    std::cin >> n >> x;

    ll rem = 0;

    for(int i = 0; i < n; i++){
        ll a;
        std::cin >> a;
        rem += a;        
        rem -= x;        
        if(rem < 0) rem = 0;
        
    }

    std::cout << rem << '\n';
}

signed main(){
    std::ios::sync_with_stdio(false) ;
    std::cin.tie(0) ;
    int tt = 1 ;
    init();
    std::cin >> tt ;
    while (tt--) solve() ;
    return 0 ;
}